package com.ssplayer.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity:AppCompatActivity(){
 private lateinit var db:LibraryDb
 private lateinit var status:TextView
 private val picker=registerForActivityResult(ActivityResultContracts.OpenDocumentTree()){uri->
  if(uri!=null){contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)
   getSharedPreferences("ssplayer",MODE_PRIVATE).edit().putString("tree",uri.toString()).apply();scan(uri)}
 }
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);db=LibraryDb(this)
  val root=LinearLayout(this).apply{orientation=1;setPadding(28,48,28,24);setBackgroundColor(0xFF100B17.toInt())}
  root.addView(TextView(this).apply{text="SSPlayer";textSize=32f;setTextColor(0xFFD8C5FF.toInt())})
  status=TextView(this).apply{text="Escolha uma pasta de músicas ou um pendrive.";textSize=16f;setTextColor(-1);setPadding(0,24,0,24)}
  root.addView(status)
  root.addView(Button(this).apply{text="Selecionar repertório";setOnClickListener{picker.launch(null)}})
  root.addView(Button(this).apply{text="Ver catálogo";setOnClickListener{status.text="Faixas: ${db.count()}\n"+db.names().joinToString("\n")}})
  setContentView(root)
 }
 private fun scan(uri:Uri){status.text="Indexando em lotes…"
  lifecycleScope.launch{try{val r=LibraryImporter(this@MainActivity,db).index(uri){n,b->runOnUiThread{status.text="Lendo… $n faixas • ${"%.2f".format(Locale.US,b/1073741824.0)} GB"}};status.text="Catálogo concluído: ${r.tracks} faixas • ${"%.2f".format(Locale.US,r.bytes/1073741824.0)} GB"}catch(e:Exception){status.text="Falha: ${e.message}"}}
 }
}
