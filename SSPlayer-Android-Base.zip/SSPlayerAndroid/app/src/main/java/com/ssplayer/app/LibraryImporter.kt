package com.ssplayer.app

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LibraryImporter(private val context:Context,private val db:LibraryDb){
 data class Result(val tracks:Int,val bytes:Long)
 suspend fun index(uri:Uri,onProgress:(Int,Long)->Unit):Result=withContext(Dispatchers.IO){
  val root=DocumentFile.fromTreeUri(context,uri)?:error("Pasta não encontrada")
  val queue=ArrayDeque<Pair<DocumentFile,String>>();queue.add(root to "")
  val batch=ArrayList<TrackCandidate>(200);var count=0;var bytes=0L
  while(queue.isNotEmpty()){
   val (dir,prefix)=queue.removeFirst()
   dir.listFiles().forEach{f->
    val name=f.name?:return@forEach
    val path=if(prefix.isEmpty())name else "$prefix/$name"
    if(f.isDirectory)queue.add(f to path)
    else if(isAudio(name,f.type)){
     val size=f.length().coerceAtLeast(0)
     batch+=TrackCandidate(name,f.uri.toString(),path,size);count++;bytes+=size
     if(batch.size==200){db.insertBatch(batch.toList());batch.clear();onProgress(count,bytes)}
    }
   }
  }
  if(batch.isNotEmpty())db.insertBatch(batch)
  onProgress(count,bytes);Result(count,bytes)
 }
 private fun isAudio(n:String,m:String?)=m?.startsWith("audio/")==true||n.substringAfterLast('.', "").lowercase() in setOf("mp3","wav","flac","m4a","aac","ogg","opus","wma","aif","aiff")
}
