package com.ssplayer.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class TrackCandidate(val name:String,val uri:String,val path:String,val size:Long)
class LibraryDb(c:Context):SQLiteOpenHelper(c,"ssplayer.db",null,1){
 override fun onCreate(db:SQLiteDatabase){
  db.execSQL("CREATE TABLE tracks(id INTEGER PRIMARY KEY, name TEXT NOT NULL, uri TEXT UNIQUE NOT NULL, path TEXT NOT NULL, size INTEGER NOT NULL)")
  db.execSQL("CREATE INDEX idx_track_path ON tracks(path)")
  db.execSQL("CREATE INDEX idx_track_name ON tracks(name)")
 }
 override fun onUpgrade(db:SQLiteDatabase,o:Int,n:Int){}
 fun insertBatch(items:List<TrackCandidate>){
  writableDatabase.beginTransaction()
  try{items.forEach{v->val c=ContentValues().apply{put("name",v.name);put("uri",v.uri);put("path",v.path);put("size",v.size)}
   writableDatabase.insertWithOnConflict("tracks",null,c,SQLiteDatabase.CONFLICT_REPLACE)}
   writableDatabase.setTransactionSuccessful()
  }finally{writableDatabase.endTransaction()}
 }
 fun count():Long=readableDatabase.rawQuery("SELECT COUNT(*) FROM tracks",null).use{it.moveToFirst();it.getLong(0)}
 fun names(limit:Int=100):List<String>{val a=mutableListOf<String>();readableDatabase.rawQuery("SELECT name FROM tracks ORDER BY path,name LIMIT ?",arrayOf(limit.toString())).use{while(it.moveToNext())a+=it.getString(0)};return a}
}
